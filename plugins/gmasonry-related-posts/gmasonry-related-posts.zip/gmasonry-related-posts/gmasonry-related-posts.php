<?php
/*
Plugin Name: Grid Masonry Related Posts
Plugin URI: http://themerex.net
Description: Add grid masonry widget for related posts in your theme
Version: 1.0
Author: ThemeREX
Author URI: http://themerex.net
*/

define('GMASONRY_RELATED_POSTS', '1.0');

add_action( 'admin_enqueue_scripts', 'themerex_backend_scripts');
if ( ! function_exists( 'themerex_backend_scripts' ) ){
	function themerex_backend_scripts() {
		wp_enqueue_media();
		wp_enqueue_style( 'wp-color-picker');
		wp_enqueue_style( 'themerex-style', plugins_url( '/css/style.css',  __FILE__ ));

		wp_enqueue_script( 'wp-color-picker');
		wp_enqueue_script( 'wp-color-picker-alpha', plugins_url( '/js/wp-color-picker-alpha.min.js',  __FILE__ ), array( 'wp-color-picker' ), '1.0.0', true );
	}
}

// Adds widget: Grid Masonry Related Posts
class Grid_Masonry_Related_Post_Widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'gridmasonryrelatedpo_widget',
			esc_html__( 'Grid Masonry Related Posts', 'themerex' ),
			array( 'description' => esc_html__( 'Add grid masonry widget', 'themerex' ), ) // Args
		);
		add_action( 'admin_footer', array( $this, 'media_fields' ) );
		add_action( 'customize_controls_print_footer_scripts', array( $this, 'media_fields' ) );

		wp_enqueue_style( 'themerex-style', plugins_url( '/css/style.css',  __FILE__ ));
		wp_enqueue_script( 'themerex-masonry', plugins_url( '/js/masonry.pkgd.min.js',  __FILE__ ), array( 'jquery' ), '', true );
		wp_enqueue_script( 'themerex-option', plugins_url( '/js/option.js',  __FILE__ ), array( 'jquery' ), '', true );
	}


	public function widget_fields (){
		$instance['features'] = array();

		$count = 0;
		$i = 8;
		while ($count < $i){
			$widget_fields = array(
				array(
					'label'	=> __( 'Block Area', 'themerex' ),
					'id'	  => 'grp_radio_'.$count,
					'type'	=> 'radio',
					'options' => array(
						'horizontal_rectangle' => __( 'Horizontal Rectangle', 'themerex' ),
						'vertical_rectangle'   => __( 'Vertical Rectangle', 'themerex' ),
						'square'	 => __( 'Square', 'themerex' ),
					),
				),
				array(
					'label' => __( 'Post Title', 'themerex' ),
					'id' => 'grp_title_'.$count,
					'type' => 'text',
				),
				array(
					'label' => __( 'Font Size Title (px)', 'themerex' ),
					'id' => 'grp_font_size_'.$count,
					'default' => 40,
					'type' => 'number',
				),
				array(
					'label' => __( 'Post Sub Title', 'themerex' ),
					'id' => 'grp_sub_title_'.$count,
					'type' => 'text',
				),
				array(
					'label' => __( 'Font Size Sub Title (px)', 'themerex' ),
					'id' => 'grp_font_size_sub_'.$count,
					'default' => 14,
					'type' => 'number',
				),
				array(
					'label' => __( 'Post Url', 'themerex' ),
					'id' => 'grp_url_'.$count,
					'type' => 'url',
				),
				array(
					'label' => __( 'Post Background Image', 'themerex' ),
					'id' => 'grp_image_'.$count,
					'type' => 'media',
				),
				array(
					'label' => __( 'Post Background Transparency', 'themerex' ),
					'id'   => 'grp_colorpicker_'.$count,
					'type' => 'colorpicker',
				),
				array(
					'label' => __( 'Post Background Color', 'themerex' ),
					'id'   => 'grp_colorpicker_bg_'.$count,
					'type' => 'colorpicker',
				),
			);
			$instance['features'][$count] = $widget_fields;

			$count++;
		}

		return $widget_fields_result = $instance['features'];

	}


	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}

		// Output generated fields
		//var_dump($instance);
		$count = 0;
		$features = ( ! empty( $instance['features'] ) ) ? $instance['features'] : array();
		$character_mask = "\t\n";
		foreach( $features as $feature ) {?>
			<div class="gmasonry-related-posts <?php echo $instance['grp_radio_'.$count];?>" style="background-image: url(<?php echo wp_get_attachment_image_src($instance['grp_image_'.$count],'full')[0];?>);background-color: <?php echo $instance['grp_colorpicker_bg_'.$count];?>;">
				<span class="transparency" style="background-color: <?php echo $instance['grp_colorpicker_'.$count];?>;"></span>
				<div class="title-block">
					<h5 class="title" style="font-size: <?php echo $instance['grp_font_size_sub_'.$count];?>px;"><?php echo trim($instance['grp_sub_title_'.$count], $character_mask);?></h5>
					<h4 class="title"  style="font-size: <?php echo $instance['grp_font_size_'.$count];?>px;"><?php echo trim($instance['grp_title_'.$count], $character_mask);?></h4>
				</div>
				<a class="grp_link" href="<?php echo $instance['grp_url_'.$count];?>"></a>
			</div>
			<?php
			++$count;
		}

		echo $args['after_widget'];
	}

	public function media_fields() {
		?><script>
			jQuery(document).ready(function($){

				$('.color-picker').wpColorPicker();

				$('.post-box h3').on('click', function(){
					$(this).next().slideToggle(200);
				});

				if ( typeof wp.media !== 'undefined' ) {
					var _custom_media = true,
						_orig_send_attachment = wp.media.editor.send.attachment;
					$(document).on('click','.custommedia',function(e) {
						var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						var id = button.attr('id');
						_custom_media = true;
						wp.media.editor.send.attachment = function(props, attachment){
							if ( _custom_media ) {
								$('input#'+id).val(attachment.id);
								$('span#preview'+id).css('background-image', 'url('+attachment.url+')');
								$('input#'+id).trigger('change');
							} else {
								return _orig_send_attachment.apply( this, [props, attachment] );
							};
						}
						wp.media.editor.open(button);
						return false;
					});
					$('.add_media').on('click', function(){
						_custom_media = false;
					});
					$(document).on('click', '.remove-media', function() {
						var parent = $(this).parents('p');
						parent.find('input[type="media"]').val('').trigger('change');
						parent.find('span').css('background-image', 'url()');
					});
				}
			});
		</script><?php
	}

	public function field_generator( $instance, $widget_fields ) {
		$output = '';
		$output .= '<div class="post-box"><h3>'.esc_html__( 'Post', 'themerex' ).'</h3><div class="post-box-content">';
		foreach ( $widget_fields as $widget_field ) {
			$default = '';
			if ( isset($widget_field['default']) ) {
				$default = $widget_field['default'];
			}
			$widget_value = ! empty( $instance[$widget_field['id']] ) ? $instance[$widget_field['id']] : esc_html__( $default, 'themerex' );
			switch ( $widget_field['type'] ) {
				case 'media':
					$media_url = '';
					if ($widget_value) {
						$media_url = wp_get_attachment_url($widget_value);
					}
					$output .= '<p>';
					$output .= '<label class="media-label" for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'themerex' ).':</label> ';
					$output .= '<input style="display:none;" class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.$widget_value.'">';
					$output .= '<span class="media-span"  id="preview'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" style="background-image:url('.$media_url.');"></span>';
					$output .= '<span class="media-button-block">';
					$output .= '<button id="'.$this->get_field_id( $widget_field['id'] ).'" class="button select-media custommedia">Add Media</button>';
					$output .= '<input style="width: 62%; margin-top: 10px;" class="button remove-media" id="buttonremove" name="buttonremove" type="button" value="Clear" />';
					$output .= '</span>';
					$output .= '</p>';
					break;

				case 'radio':
					$output .= '<p>';
					$output .= '<label class="radio-label" for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'themerex' ).':</label> ';
					$count_radio = 0;
					$radio_value = array_keys($widget_field['options']);
					$cheked = '';
					foreach ($widget_field['options'] as $option){
						if(isset($instance[$widget_field['id']])) {
							$cheked =  ($radio_value[$count_radio] == $instance[$widget_field['id']]) ? 'checked' : '';
						}
						$output .= '<label class="radio-label" for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $option, 'themerex' ).':</label> ';
						$output .= '<input class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.esc_attr( $radio_value[$count_radio] ).'" '.$cheked.'>';
						$count_radio++;
					}
					$output .= '</p>';
					break;

				case 'colorpicker':
					$output .= '<p>';
					$output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'themerex' ).':</label> ';
					$output .= '<input class="widefat color-picker" data-alpha="true" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.esc_attr( $widget_value ).'">';
					$output .= '</p>';
					break;

				default:
					$output .= '<p>';
					$output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'themerex' ).':</label> ';
					$output .= '<input class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.esc_attr( $widget_value ).'">';
					$output .= '</p>';
			}
		}
		$output .= '</div></div>';
		echo $output;
	}

	public function form( $instance ) {

		echo '<div class="accordion">';
		$instance['features'] = $this->widget_fields();

		foreach ($instance['features'] as $widget_array){
			$this->field_generator( $instance, $widget_array);
		}
		
		echo '</div>';

		if (wp_doing_ajax()){
			?><script>
				jQuery(document).ready(function($){
					$('.color-picker').wpColorPicker();

					$('.post-box h3').on('click', function(){
						$(this).next().slideToggle(200);
					});
				});
			</script><?php
		}
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['features'] = $this->widget_fields();

		foreach ( $instance['features'] as $widget_fields ) {
			foreach ( $widget_fields as $widget_field ) {
				switch ( $widget_field['type'] ) {
					default:
						$instance[ $widget_field['id'] ] = ( ! empty( $new_instance[ $widget_field['id'] ] ) ) ? strip_tags( $new_instance[ $widget_field['id'] ] ) : '';
				}
			}
		}
		return $instance;
	}
}

function register_gridmasonryrelatedpo_widget() {
	register_widget( 'Grid_Masonry_Related_Post_Widget' );
}
add_action( 'widgets_init', 'register_gridmasonryrelatedpo_widget' );